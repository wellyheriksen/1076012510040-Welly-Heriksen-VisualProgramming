package com.example.week2no1vp.viewmodel

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.week2no1vp.R

@Composable
fun Soal1() {
    val backgroundcolor = Color(0xFF2C2C2C)
    val textcolor = Color.White

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = backgroundcolor,
        contentColor = textcolor
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.KeyboardArrowDown, contentDescription = null,
                    tint = Color.White
                )
                Text(
                    text = "Favorite Songs",
                    fontSize= 22.sp
                )
                Icon(Icons.Default.MoreVert, contentDescription = null)
            }
            Spacer(modifier = Modifier.height(10.dp))
            // Gambar
            Image(
                painter = painterResource(id = R.drawable.moana),
                contentDescription = "Sampul Album Moana",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(horizontal = 32.dp)
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(15.dp))
            )
            Spacer(modifier = Modifier.height(10.dp))
            //lirik
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "How Far I'll Go", fontSize = 30.sp, fontWeight = FontWeight.Bold

                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "DisneyMusicVEVO",
                        fontSize = 18.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.FavoriteBorder,
                    contentDescription = "fav",
                    modifier = Modifier.size(32.dp)
                )
            }
            //durasi
            Slider(
                value = 0.5f,
                onValueChange = { },
                modifier = Modifier.fillMaxWidth()
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(text = "1:12", fontSize = 15.sp)
                Text(text = "2:54", fontSize = 15.sp)
            }
            Spacer(modifier = Modifier.height(16.dp))
            //tombol play,dll
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.SkipPrevious,
                    contentDescription = "",
                    modifier = Modifier.size(40.dp)
                )
                Box(
                    modifier = Modifier
                        .size(70.dp)
                        .background(Color.Black, shape = RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "tombolplay",
                        modifier = Modifier.size(32.dp)
                    )
                }
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "",
                    modifier = Modifier.size(40.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black)
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Lyrics",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = """
                        I've been staring at the edge of the water
                        Long as I can remember, never really knowing why
                        I wish I could be the perfect daughter
                        But I come back to the water, no matter how hard I try
                        Every turn I take, every trail I track
                        Every path I make, every road leads back
                        To the place I know, where I can not go
                        Where I long to be
                        See the line where the sky meets the sea? it calls me
                        And no one knows how far it goes
                        If the wind in my sail on the sea stays behind me
                        One day I'll know
                        If I go, there's just no telling how far I'll go
                        Oh, oh, oh, oh, oh, oh, oh
                        Oh, oh, oh, oh, oh
                        Oh, oh, oh, oh, oh, oh, oh, oh
                        Oh, oh, oh, oh, oh
                        I know everybody on this island
                        Seems so happy on this island
                        Everything is by design
                        I know everybody on this island
                        Has a role on this island
                        So maybe I can roll with mine
                        I can lead with pride, I can make us strong
                        I'll be satisfied if I play along
                        But the voice inside sings a different song
                        What is wrong with me?
                        See the light as it shines on the sea, it's blinding
                        But no one knows how deep it goes
                        And it seems like it's calling out to me, so come find me
                        And let me know what's beyond that line
                        Will I cross that line?
                        See the line where the sky meets the sea, it calls me
                        And no one knows how far it goes
                        If the wind in my sail on the sea stays behind me
                        One day I'll know how far I'll go
                    """.trimIndent(),
                    fontSize = 16.sp,
                    lineHeight = 24.sp,
                )
            }
        }
    }
}

@Composable
@Preview(showBackground = true, showSystemUi = true)
private fun LoginPreview() {
    Soal1()
}
